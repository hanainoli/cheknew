package com.ncr.chess;

public class ChessBoard {

    public static int MAX_BOARD_WIDTH = 7;
    public static int MAX_BOARD_HEIGHT = 7;

    private Pawn[][] pieces;
    
    //private Pawn pawn;
    public ChessBoard() {
        pieces = new Pawn[MAX_BOARD_WIDTH][MAX_BOARD_HEIGHT];
    }

    public Pawn[][]  addPiece(Pawn pawn, int xCoordinate, int yCoordinate, PieceColor pieceColor) {
    	if(pieceColor == PieceColor.BLACK) {
    		
    		for(int row=0; row<pieces.length; row++) {
    			 for(int col=0; col <pieces[row].length; col++) {
    				 
    				 if(row == xCoordinate && col == yCoordinate) {
    					 Pawn childPawn = new Pawn(pieceColor);
    					 childPawn.setYCoordinate(yCoordinate);
    					 childPawn.setXCoordinate(xCoordinate);
    					 pieces[row][col] = childPawn;
    					 break;
    				 }
    				 
    				 
    			 }
    			
    			
    		}
    		
    		
    		
    		//pieces = new Pawn[xCoordinate][yCoordinate];
    	}else {
    		throw new UnsupportedOperationException("Need to implement ChessBoard.add()");
    	}
    	
    	return pieces;
      //  
    }
    
    public void  addPiece1(Pawn pawn, int xCoordinate, int yCoordinate, PieceColor pieceColor) {
    	if(pieceColor == PieceColor.BLACK) {
    		
    		for(int row=0; row<pieces.length; row++) {
    			 for(int col=0; col <pieces[row].length; col++) {
    				 
    				 if(row == xCoordinate && col == yCoordinate) {
    					 Pawn childPawn = new Pawn(pieceColor);
    					 childPawn.setYCoordinate(yCoordinate);
    					 childPawn.setXCoordinate(xCoordinate);
    					 pieces[row][col] = childPawn;
    					 break;
    				 }
    				 
    				 
    			 }
    			
    			
    		}
    		
    		
    		
    		//pieces = new Pawn[xCoordinate][yCoordinate];
    	}else {
    		throw new UnsupportedOperationException("Need to implement ChessBoard.add()");
    	}
    	
    	//return pieces;
      //  
    }

    public boolean isLegalBoardPosition(int xCoordinate, int yCoordinate) {
        throw new UnsupportedOperationException("Need to implement ChessBoard.IsLegalBoardPosition()");
    }
}
