package com.ncr.chess;

public class Pawn {

    private ChessBoard chessBoard;
    private int xCoordinate;
    private int yCoordinate;
    private PieceColor pieceColor;
    public Pawn() {
    }
    
    public Pawn(PieceColor pieceColor) {
        this.pieceColor = pieceColor;
    }
    


    public ChessBoard getChessBoard() {
        return chessBoard;
    }

    public void setChessBoard(ChessBoard chessBoard) {
        this.chessBoard = chessBoard;
    }

    public int getXCoordinate() {
        return xCoordinate;
    }

    public void setXCoordinate(int value) {
        this.xCoordinate = value;
    }

    public int getYCoordinate() {
        return yCoordinate;
    }

    public void setYCoordinate(int value) {
        this.yCoordinate = value;
    }

    public PieceColor getPieceColor() {
        return this.pieceColor;
    }

    private void setPieceColor(PieceColor value) {
        pieceColor = value;
    }

    public void move(MovementType movementType, int newX, int newY) {
    	
    	if(movementType == MovementType.MOVE) {
//    		chessBoard.
    		
    		
    	}
        throw new UnsupportedOperationException("Need to implement Pawn.Move()") ;
    }
    
    public Pawn move(Pawn[][] pieces,MovementType movementType, int newX, int newY) {
    	 Pawn childPawn = null;
    	if(movementType == MovementType.MOVE) {
    		
    		for(int row=0; row<pieces.length; row++) {
    			 for(int col=0; col <pieces[row].length; col++) {
    				 
    				
    				 childPawn = pieces[row][col];
    				 if( childPawn != null && childPawn.getYCoordinate() > 0 && childPawn.getXCoordinate() >0) {
    					 
    					 childPawn = updatePawn(childPawn, newX,  newY);
    					 break;
    					 
    				 }
    				 
    				 
    				 
    			 }
    			
    			
    		}
    		
    		
    	}
    	
    	return childPawn;
      //  throw new UnsupportedOperationException("Need to implement Pawn.Move()") ;
    }
    
    public Pawn updatePawn(Pawn childPawn,int newX, int newY ) {
    	
    	//Pawn childNew = childPawn;
    int xValue = childPawn.getXCoordinate();
    int yVlaue = childPawn.getYCoordinate();
    //if it left side direction not allowed
    if(xValue >=0 && yVlaue >=0  && newX < xValue && (newX != minValueFound(xValue,newX ))) {
    	
    	//if(x == newX || )
    	
    	childPawn.setXCoordinate(newX);
    	childPawn.setYCoordinate(newY);
    	
    	//right side direction not allowd
    }else if (xValue >=0 && yVlaue >=0  && newX > xValue && (newX != maxValueFound(xValue,newX )))  {
    	childPawn.setXCoordinate(newX);
    	childPawn.setYCoordinate(newY);
    	
    }//forward Direction
    else if (xValue >=0 && yVlaue >=0  && newY < yVlaue && (newY == minValueFound(yVlaue,newY )))  {
    	childPawn.setXCoordinate(newX);
    	childPawn.setYCoordinate(newY);
    	
    }
    
    return childPawn;
    }
    
    public int  minValueFound(int xValue, int newX) {
    	
    	if(xValue < 0) {
    		return 0;
    	}
    	if(xValue == newX) {
    		return newX;
    	}
    	return minValueFound(xValue -1, newX);
    }
    
    public int  maxValueFound(int xValue, int newX) {
    	if(xValue <= 7) {
    		return 7;
    	}
    	if(xValue == newX) {
    		return newX;
    	}
    	return maxValueFound(xValue +1, newX);
    }

    @Override
    public String toString() {
        return getCurrentPositionAsString();
    }

    protected String getCurrentPositionAsString() {
        String eol = System.lineSeparator();
        return String.format("Current X: {1}{0}Current Y: {2}{0}Piece Color: {3}", eol, xCoordinate, yCoordinate, pieceColor);
    }
}
